import {BasePage} from './BasePage';

class Login extends BasePage {
  constructor () {
    super();

    this.icon = '[data-menu-action="country-selector--is-visible"]';

    
  }

  goToPage () {
    cy.visit('https://www.willistowerswatson.com/ICT', { timeout: 30000 });
    
  }

  clickAgreedButton () {
    cy.get('.call').contains('Agree and Proceed');
  }

  clickCountryAndLanuage() {
    cy.get('.material-icons').contains('language').click();
    cy.get('.country-selector__icon').eq(0).click();
    cy.get('.col-md-5').eq(18).click();
  }

  clickSearch() {
    cy.get('.material-icons').contains('search').click();
  }

  clickEnterValue() {
    cy.get('.magic-box-input').type('IFRS 17');
  }

  clickSearchButton() {
    cy.get('.coveo-accessible-button').eq(0).click();
  }

  checkValidResultPage() {
    cy.url().should('eq', 'https://www.willistowerswatson.com/en-US/Search#q=IFRS%2017&sort=relevancy')
  //  cy.get('.wtw-coveo-split-header').should('have.value', 'IFRS 17')
  }

  selectContentType() {
    cy.wait(3000);
    cy.get('.coveo-facet-value-checkbox').contains('Article').check();
    

  }

}

export const login = new Login();