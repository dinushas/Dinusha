export class BasePage {

}