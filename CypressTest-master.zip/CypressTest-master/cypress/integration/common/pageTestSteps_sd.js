import { login } from '../../support/PageObjects/Login_po.js';

beforeEach(function () {
  Cypress.on('uncaught:exception', (err, runnable) => {
    return false;
  });
})

given('user open google page', () => {
  // Cypress.on('uncaught:exception', (err, runnable) => {
  //   return false;
  // });
  login.goToPage();
  //cy.wait(10000);
});

and('User clicks on Agree and Proceed', () => {
  login.clickAgreedButton();
})

and('User clicks on country', () => {
  login.clickCountryAndLanuage();
})

and('User click on Search', () => {
  login.clickSearch();
})

and('User enter value', () => {
  login.clickEnterValue();
})

and('user clicks on search', () => {
  login.clickSearchButton();
})

and('User checks result page', () => {
  login.checkValidResultPage();
})

// and('User set content type to Article', () => {
//   login.checkValidResultPage();
// })

and('User set content type to Article', () => {
  login.selectContentType();
})














